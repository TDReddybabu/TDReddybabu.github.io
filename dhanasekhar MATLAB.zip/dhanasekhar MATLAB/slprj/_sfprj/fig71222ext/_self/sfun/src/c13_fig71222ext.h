#ifndef __c13_fig71222ext_h__
#define __c13_fig71222ext_h__

/* Include files */
#include "sf_runtime/sfc_sf.h"
#include "sf_runtime/sfc_mex.h"
#include "rtwtypes.h"
#include "multiword_types.h"

/* Type Definitions */
#ifndef typedef_SFc13_fig71222extInstanceStruct
#define typedef_SFc13_fig71222extInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint8_T c13_is_active_c13_fig71222ext;
  real_T c13_Vold;
  boolean_T c13_Vold_not_empty;
  real_T c13_Pold;
  boolean_T c13_Pold_not_empty;
  real_T c13_Dold;
  boolean_T c13_Dold_not_empty;
  real_T c13_Iold;
  boolean_T c13_Iold_not_empty;
} SFc13_fig71222extInstanceStruct;

#endif                                 /*typedef_SFc13_fig71222extInstanceStruct*/

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c13_fig71222ext_get_eml_resolved_functions_info(void);

/* Function Definitions */
extern void sf_c13_fig71222ext_get_check_sum(mxArray *plhs[]);
extern void c13_fig71222ext_method_dispatcher(SimStruct *S, int_T method, void
  *data);

#endif
