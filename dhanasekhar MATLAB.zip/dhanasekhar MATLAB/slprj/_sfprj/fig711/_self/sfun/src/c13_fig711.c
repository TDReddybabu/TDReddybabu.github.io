/* Include files */

#include "blascompat32.h"
#include "fig711_sfun.h"
#include "c13_fig711.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
static void initialize_c13_fig711(SFc13_fig711InstanceStruct *chartInstance);
static void initialize_params_c13_fig711(SFc13_fig711InstanceStruct
  *chartInstance);
static void enable_c13_fig711(SFc13_fig711InstanceStruct *chartInstance);
static void disable_c13_fig711(SFc13_fig711InstanceStruct *chartInstance);
static const mxArray *get_sim_state_c13_fig711(SFc13_fig711InstanceStruct
  *chartInstance);
static void set_sim_state_c13_fig711(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_st);
static void finalize_c13_fig711(SFc13_fig711InstanceStruct *chartInstance);
static void sf_c13_fig711(SFc13_fig711InstanceStruct *chartInstance);
static void initSimStructsc13_fig711(SFc13_fig711InstanceStruct *chartInstance);
static void init_script_number_translation(uint32_T c13_machineNumber, uint32_T
  c13_chartNumber);
static real_T c13_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_D, const char_T *c13_identifier);
static real_T c13_b_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_u, const emlrtMsgIdentifier *c13_parentId);
static real_T c13_c_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_b_Dold, const char_T *c13_identifier);
static real_T c13_d_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_u, const emlrtMsgIdentifier *c13_parentId);
static real_T c13_e_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_b_Iold, const char_T *c13_identifier);
static real_T c13_f_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_u, const emlrtMsgIdentifier *c13_parentId);
static real_T c13_g_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_b_Pold, const char_T *c13_identifier);
static real_T c13_h_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_u, const emlrtMsgIdentifier *c13_parentId);
static real_T c13_i_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_b_Vold, const char_T *c13_identifier);
static real_T c13_j_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_u, const emlrtMsgIdentifier *c13_parentId);
static uint8_T c13_k_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_b_is_active_c13_fig711, const char_T *c13_identifier);
static uint8_T c13_l_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_u, const emlrtMsgIdentifier *c13_parentId);
static void init_dsm_address_info(SFc13_fig711InstanceStruct *chartInstance);

/* Function Definitions */
static void initialize_c13_fig711(SFc13_fig711InstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  chartInstance->c13_Vold_not_empty = FALSE;
  chartInstance->c13_Pold_not_empty = FALSE;
  chartInstance->c13_Dold_not_empty = FALSE;
  chartInstance->c13_Iold_not_empty = FALSE;
  chartInstance->c13_is_active_c13_fig711 = 0U;
}

static void initialize_params_c13_fig711(SFc13_fig711InstanceStruct
  *chartInstance)
{
}

static void enable_c13_fig711(SFc13_fig711InstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static void disable_c13_fig711(SFc13_fig711InstanceStruct *chartInstance)
{
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
}

static const mxArray *get_sim_state_c13_fig711(SFc13_fig711InstanceStruct
  *chartInstance)
{
  const mxArray *c13_st;
  const mxArray *c13_y = NULL;
  real_T c13_u;
  const mxArray *c13_b_y = NULL;
  real_T c13_b_u;
  const mxArray *c13_c_y = NULL;
  real_T c13_c_u;
  const mxArray *c13_d_y = NULL;
  real_T c13_d_u;
  const mxArray *c13_e_y = NULL;
  real_T c13_e_u;
  const mxArray *c13_f_y = NULL;
  uint8_T c13_f_u;
  const mxArray *c13_g_y = NULL;
  real_T *c13_D;
  c13_D = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c13_st = NULL;
  c13_y = NULL;
  sf_mex_assign(&c13_y, sf_mex_createcellarray(6));
  c13_u = *c13_D;
  c13_b_y = NULL;
  sf_mex_assign(&c13_b_y, sf_mex_create("y", &c13_u, 0, 0U, 0U, 0U, 0));
  sf_mex_setcell(c13_y, 0, c13_b_y);
  c13_b_u = chartInstance->c13_Dold;
  c13_c_y = NULL;
  if (!chartInstance->c13_Dold_not_empty) {
    sf_mex_assign(&c13_c_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c13_c_y, sf_mex_create("y", &c13_b_u, 0, 0U, 0U, 0U, 0));
  }

  sf_mex_setcell(c13_y, 1, c13_c_y);
  c13_c_u = chartInstance->c13_Iold;
  c13_d_y = NULL;
  if (!chartInstance->c13_Iold_not_empty) {
    sf_mex_assign(&c13_d_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c13_d_y, sf_mex_create("y", &c13_c_u, 0, 0U, 0U, 0U, 0));
  }

  sf_mex_setcell(c13_y, 2, c13_d_y);
  c13_d_u = chartInstance->c13_Pold;
  c13_e_y = NULL;
  if (!chartInstance->c13_Pold_not_empty) {
    sf_mex_assign(&c13_e_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c13_e_y, sf_mex_create("y", &c13_d_u, 0, 0U, 0U, 0U, 0));
  }

  sf_mex_setcell(c13_y, 3, c13_e_y);
  c13_e_u = chartInstance->c13_Vold;
  c13_f_y = NULL;
  if (!chartInstance->c13_Vold_not_empty) {
    sf_mex_assign(&c13_f_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0));
  } else {
    sf_mex_assign(&c13_f_y, sf_mex_create("y", &c13_e_u, 0, 0U, 0U, 0U, 0));
  }

  sf_mex_setcell(c13_y, 4, c13_f_y);
  c13_f_u = chartInstance->c13_is_active_c13_fig711;
  c13_g_y = NULL;
  sf_mex_assign(&c13_g_y, sf_mex_create("y", &c13_f_u, 3, 0U, 0U, 0U, 0));
  sf_mex_setcell(c13_y, 5, c13_g_y);
  sf_mex_assign(&c13_st, c13_y);
  return c13_st;
}

static void set_sim_state_c13_fig711(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_st)
{
  const mxArray *c13_u;
  real_T *c13_D;
  c13_D = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c13_u = sf_mex_dup(c13_st);
  *c13_D = c13_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c13_u,
    0)), "D");
  chartInstance->c13_Dold = c13_c_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c13_u, 1)), "Dold");
  chartInstance->c13_Iold = c13_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c13_u, 2)), "Iold");
  chartInstance->c13_Pold = c13_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c13_u, 3)), "Pold");
  chartInstance->c13_Vold = c13_i_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c13_u, 4)), "Vold");
  chartInstance->c13_is_active_c13_fig711 = c13_k_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c13_u, 5)), "is_active_c13_fig711");
  sf_mex_destroy(&c13_u);
  sf_mex_destroy(&c13_st);
}

static void finalize_c13_fig711(SFc13_fig711InstanceStruct *chartInstance)
{
}

static void sf_c13_fig711(SFc13_fig711InstanceStruct *chartInstance)
{
  real_T c13_P;
  real_T c13_dV;
  real_T c13_dP;
  real_T c13_dI;
  real_T *c13_D;
  real_T *c13_V;
  real_T *c13_I;
  real_T *c13_Enabled;
  real_T (*c13_Param)[4];
  c13_D = (real_T *)ssGetOutputPortSignal(chartInstance->S, 1);
  c13_I = (real_T *)ssGetInputPortSignal(chartInstance->S, 3);
  c13_V = (real_T *)ssGetInputPortSignal(chartInstance->S, 2);
  c13_Enabled = (real_T *)ssGetInputPortSignal(chartInstance->S, 1);
  c13_Param = (real_T (*)[4])ssGetInputPortSignal(chartInstance->S, 0);
  _sfTime_ = (real_T)ssGetT(chartInstance->S);
  if (!chartInstance->c13_Vold_not_empty) {
    chartInstance->c13_Vold = 0.0;
    chartInstance->c13_Vold_not_empty = TRUE;
    chartInstance->c13_Iold = 0.0;
    chartInstance->c13_Iold_not_empty = TRUE;
    chartInstance->c13_Pold = 0.0;
    chartInstance->c13_Pold_not_empty = TRUE;
    chartInstance->c13_Dold = (*c13_Param)[0];
    chartInstance->c13_Dold_not_empty = TRUE;
  }

  c13_P = *c13_V * *c13_I;
  c13_dV = *c13_V - chartInstance->c13_Vold;
  c13_dP = c13_P - chartInstance->c13_Pold;
  c13_dI = *c13_I - chartInstance->c13_Iold;
  if ((c13_dP != 0.0) && (*c13_Enabled != 0.0)) {
    if (c13_dP < 0.0) {
      if (c13_dI / c13_dV > -*c13_I / *c13_V) {
        *c13_D = chartInstance->c13_Dold - (*c13_Param)[3];
      } else {
        *c13_D = chartInstance->c13_Dold + (*c13_Param)[3];
      }
    } else if (c13_dI / c13_dV < -*c13_I / *c13_V) {
      *c13_D = chartInstance->c13_Dold + (*c13_Param)[3];
    } else {
      *c13_D = chartInstance->c13_Dold - (*c13_Param)[3];
    }
  } else {
    *c13_D = chartInstance->c13_Dold;
  }

  if ((*c13_D >= (*c13_Param)[1]) || (*c13_D <= (*c13_Param)[2])) {
    *c13_D = chartInstance->c13_Dold;
  }

  chartInstance->c13_Dold = *c13_D;
  chartInstance->c13_Vold = *c13_V;
  chartInstance->c13_Pold = c13_P;
}

static void initSimStructsc13_fig711(SFc13_fig711InstanceStruct *chartInstance)
{
}

static void init_script_number_translation(uint32_T c13_machineNumber, uint32_T
  c13_chartNumber)
{
}

const mxArray *sf_c13_fig711_get_eml_resolved_functions_info(void)
{
  const mxArray *c13_nameCaptureInfo;
  c13_ResolvedFunctionInfo c13_info[4];
  c13_ResolvedFunctionInfo (*c13_b_info)[4];
  const mxArray *c13_m0 = NULL;
  int32_T c13_i0;
  c13_ResolvedFunctionInfo *c13_r0;
  c13_nameCaptureInfo = NULL;
  c13_b_info = (c13_ResolvedFunctionInfo (*)[4])c13_info;
  (*c13_b_info)[0].context = "";
  (*c13_b_info)[0].name = "mtimes";
  (*c13_b_info)[0].dominantType = "double";
  (*c13_b_info)[0].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*c13_b_info)[0].fileTimeLo = 486824448U;
  (*c13_b_info)[0].fileTimeHi = 30114262U;
  (*c13_b_info)[0].mFileTimeLo = 0U;
  (*c13_b_info)[0].mFileTimeHi = 0U;
  (*c13_b_info)[1].context = "";
  (*c13_b_info)[1].name = "mrdivide";
  (*c13_b_info)[1].dominantType = "double";
  (*c13_b_info)[1].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p";
  (*c13_b_info)[1].fileTimeLo = 3325855488U;
  (*c13_b_info)[1].fileTimeHi = 30130897U;
  (*c13_b_info)[1].mFileTimeLo = 486824448U;
  (*c13_b_info)[1].mFileTimeHi = 30114262U;
  (*c13_b_info)[2].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mrdivide.p";
  (*c13_b_info)[2].name = "rdivide";
  (*c13_b_info)[2].dominantType = "double";
  (*c13_b_info)[2].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  (*c13_b_info)[2].fileTimeLo = 401443328U;
  (*c13_b_info)[2].fileTimeHi = 30107982U;
  (*c13_b_info)[2].mFileTimeLo = 0U;
  (*c13_b_info)[2].mFileTimeHi = 0U;
  (*c13_b_info)[3].context =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/rdivide.m";
  (*c13_b_info)[3].name = "eml_div";
  (*c13_b_info)[3].dominantType = "double";
  (*c13_b_info)[3].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/eml/eml_div.m";
  (*c13_b_info)[3].fileTimeLo = 3236410624U;
  (*c13_b_info)[3].fileTimeHi = 30107981U;
  (*c13_b_info)[3].mFileTimeLo = 0U;
  (*c13_b_info)[3].mFileTimeHi = 0U;
  sf_mex_assign(&c13_m0, sf_mex_createstruct("nameCaptureInfo", 1, 4));
  for (c13_i0 = 0; c13_i0 < 4; c13_i0++) {
    c13_r0 = &c13_info[c13_i0];
    sf_mex_addfield(c13_m0, sf_mex_create("nameCaptureInfo", c13_r0->context, 15,
      0U, 0U, 0U, 2, 1, strlen(c13_r0->context)), "context", "nameCaptureInfo",
                    c13_i0);
    sf_mex_addfield(c13_m0, sf_mex_create("nameCaptureInfo", c13_r0->name, 15,
      0U, 0U, 0U, 2, 1, strlen(c13_r0->name)), "name", "nameCaptureInfo", c13_i0);
    sf_mex_addfield(c13_m0, sf_mex_create("nameCaptureInfo",
      c13_r0->dominantType, 15, 0U, 0U, 0U, 2, 1, strlen(c13_r0->dominantType)),
                    "dominantType", "nameCaptureInfo", c13_i0);
    sf_mex_addfield(c13_m0, sf_mex_create("nameCaptureInfo", c13_r0->resolved,
      15, 0U, 0U, 0U, 2, 1, strlen(c13_r0->resolved)), "resolved",
                    "nameCaptureInfo", c13_i0);
    sf_mex_addfield(c13_m0, sf_mex_create("nameCaptureInfo", &c13_r0->fileTimeLo,
      7, 0U, 0U, 0U, 0), "fileTimeLo", "nameCaptureInfo", c13_i0);
    sf_mex_addfield(c13_m0, sf_mex_create("nameCaptureInfo", &c13_r0->fileTimeHi,
      7, 0U, 0U, 0U, 0), "fileTimeHi", "nameCaptureInfo", c13_i0);
    sf_mex_addfield(c13_m0, sf_mex_create("nameCaptureInfo",
      &c13_r0->mFileTimeLo, 7, 0U, 0U, 0U, 0), "mFileTimeLo", "nameCaptureInfo",
                    c13_i0);
    sf_mex_addfield(c13_m0, sf_mex_create("nameCaptureInfo",
      &c13_r0->mFileTimeHi, 7, 0U, 0U, 0U, 0), "mFileTimeHi", "nameCaptureInfo",
                    c13_i0);
  }

  sf_mex_assign(&c13_nameCaptureInfo, c13_m0);
  return c13_nameCaptureInfo;
}

static real_T c13_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_D, const char_T *c13_identifier)
{
  real_T c13_y;
  emlrtMsgIdentifier c13_thisId;
  c13_thisId.fIdentifier = c13_identifier;
  c13_thisId.fParent = NULL;
  c13_y = c13_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c13_D), &c13_thisId);
  sf_mex_destroy(&c13_D);
  return c13_y;
}

static real_T c13_b_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_u, const emlrtMsgIdentifier *c13_parentId)
{
  real_T c13_y;
  real_T c13_d0;
  sf_mex_import(c13_parentId, sf_mex_dup(c13_u), &c13_d0, 1, 0, 0U, 0, 0U, 0);
  c13_y = c13_d0;
  sf_mex_destroy(&c13_u);
  return c13_y;
}

static real_T c13_c_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_b_Dold, const char_T *c13_identifier)
{
  real_T c13_y;
  emlrtMsgIdentifier c13_thisId;
  c13_thisId.fIdentifier = c13_identifier;
  c13_thisId.fParent = NULL;
  c13_y = c13_d_emlrt_marshallIn(chartInstance, sf_mex_dup(c13_b_Dold),
    &c13_thisId);
  sf_mex_destroy(&c13_b_Dold);
  return c13_y;
}

static real_T c13_d_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_u, const emlrtMsgIdentifier *c13_parentId)
{
  real_T c13_y;
  real_T c13_d1;
  if (mxIsEmpty(c13_u)) {
    chartInstance->c13_Dold_not_empty = FALSE;
  } else {
    chartInstance->c13_Dold_not_empty = TRUE;
    sf_mex_import(c13_parentId, sf_mex_dup(c13_u), &c13_d1, 1, 0, 0U, 0, 0U, 0);
    c13_y = c13_d1;
  }

  sf_mex_destroy(&c13_u);
  return c13_y;
}

static real_T c13_e_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_b_Iold, const char_T *c13_identifier)
{
  real_T c13_y;
  emlrtMsgIdentifier c13_thisId;
  c13_thisId.fIdentifier = c13_identifier;
  c13_thisId.fParent = NULL;
  c13_y = c13_f_emlrt_marshallIn(chartInstance, sf_mex_dup(c13_b_Iold),
    &c13_thisId);
  sf_mex_destroy(&c13_b_Iold);
  return c13_y;
}

static real_T c13_f_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_u, const emlrtMsgIdentifier *c13_parentId)
{
  real_T c13_y;
  real_T c13_d2;
  if (mxIsEmpty(c13_u)) {
    chartInstance->c13_Iold_not_empty = FALSE;
  } else {
    chartInstance->c13_Iold_not_empty = TRUE;
    sf_mex_import(c13_parentId, sf_mex_dup(c13_u), &c13_d2, 1, 0, 0U, 0, 0U, 0);
    c13_y = c13_d2;
  }

  sf_mex_destroy(&c13_u);
  return c13_y;
}

static real_T c13_g_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_b_Pold, const char_T *c13_identifier)
{
  real_T c13_y;
  emlrtMsgIdentifier c13_thisId;
  c13_thisId.fIdentifier = c13_identifier;
  c13_thisId.fParent = NULL;
  c13_y = c13_h_emlrt_marshallIn(chartInstance, sf_mex_dup(c13_b_Pold),
    &c13_thisId);
  sf_mex_destroy(&c13_b_Pold);
  return c13_y;
}

static real_T c13_h_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_u, const emlrtMsgIdentifier *c13_parentId)
{
  real_T c13_y;
  real_T c13_d3;
  if (mxIsEmpty(c13_u)) {
    chartInstance->c13_Pold_not_empty = FALSE;
  } else {
    chartInstance->c13_Pold_not_empty = TRUE;
    sf_mex_import(c13_parentId, sf_mex_dup(c13_u), &c13_d3, 1, 0, 0U, 0, 0U, 0);
    c13_y = c13_d3;
  }

  sf_mex_destroy(&c13_u);
  return c13_y;
}

static real_T c13_i_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_b_Vold, const char_T *c13_identifier)
{
  real_T c13_y;
  emlrtMsgIdentifier c13_thisId;
  c13_thisId.fIdentifier = c13_identifier;
  c13_thisId.fParent = NULL;
  c13_y = c13_j_emlrt_marshallIn(chartInstance, sf_mex_dup(c13_b_Vold),
    &c13_thisId);
  sf_mex_destroy(&c13_b_Vold);
  return c13_y;
}

static real_T c13_j_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_u, const emlrtMsgIdentifier *c13_parentId)
{
  real_T c13_y;
  real_T c13_d4;
  if (mxIsEmpty(c13_u)) {
    chartInstance->c13_Vold_not_empty = FALSE;
  } else {
    chartInstance->c13_Vold_not_empty = TRUE;
    sf_mex_import(c13_parentId, sf_mex_dup(c13_u), &c13_d4, 1, 0, 0U, 0, 0U, 0);
    c13_y = c13_d4;
  }

  sf_mex_destroy(&c13_u);
  return c13_y;
}

static uint8_T c13_k_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_b_is_active_c13_fig711, const char_T *c13_identifier)
{
  uint8_T c13_y;
  emlrtMsgIdentifier c13_thisId;
  c13_thisId.fIdentifier = c13_identifier;
  c13_thisId.fParent = NULL;
  c13_y = c13_l_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c13_b_is_active_c13_fig711), &c13_thisId);
  sf_mex_destroy(&c13_b_is_active_c13_fig711);
  return c13_y;
}

static uint8_T c13_l_emlrt_marshallIn(SFc13_fig711InstanceStruct *chartInstance,
  const mxArray *c13_u, const emlrtMsgIdentifier *c13_parentId)
{
  uint8_T c13_y;
  uint8_T c13_u0;
  sf_mex_import(c13_parentId, sf_mex_dup(c13_u), &c13_u0, 1, 3, 0U, 0, 0U, 0);
  c13_y = c13_u0;
  sf_mex_destroy(&c13_u);
  return c13_y;
}

static void init_dsm_address_info(SFc13_fig711InstanceStruct *chartInstance)
{
}

/* SFunction Glue Code */
void sf_c13_fig711_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3700299140U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3034764223U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(1680835111U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(3264894094U);
}

mxArray *sf_c13_fig711_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs", "locals" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1,1,5,
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateDoubleMatrix(4,1,mxREAL);
    double *pr = mxGetPr(mxChecksum);
    pr[0] = (double)(3653803942U);
    pr[1] = (double)(231845287U);
    pr[2] = (double)(297441337U);
    pr[3] = (double)(3285573670U);
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,4,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(4);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,2,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(1);
      pr[1] = (double)(1);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt" };

      mxArray *mxType = mxCreateStructMatrix(1,1,2,typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"locals",mxCreateDoubleMatrix(0,0,mxREAL));
  }

  return(mxAutoinheritanceInfo);
}

static const mxArray *sf_get_sim_state_info_c13_fig711(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x6'type','srcId','name','auxInfo'{{M[1],M[5],T\"D\",},{M[4],M[0],T\"Dold\",S'l','i','p'{{M1x2[586 590],M[0],}}},{M[4],M[0],T\"Iold\",S'l','i','p'{{M1x2[591 595],M[0],}}},{M[4],M[0],T\"Pold\",S'l','i','p'{{M1x2[581 585],M[0],}}},{M[4],M[0],T\"Vold\",S'l','i','p'{{M1x2[576 580],M[0],}}},{M[8],M[0],T\"is_active_c13_fig711\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 6, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c13_fig711_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static void sf_opaque_initialize_c13_fig711(void *chartInstanceVar)
{
  initialize_params_c13_fig711((SFc13_fig711InstanceStruct*) chartInstanceVar);
  initialize_c13_fig711((SFc13_fig711InstanceStruct*) chartInstanceVar);
}

static void sf_opaque_enable_c13_fig711(void *chartInstanceVar)
{
  enable_c13_fig711((SFc13_fig711InstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c13_fig711(void *chartInstanceVar)
{
  disable_c13_fig711((SFc13_fig711InstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c13_fig711(void *chartInstanceVar)
{
  sf_c13_fig711((SFc13_fig711InstanceStruct*) chartInstanceVar);
}

extern const mxArray* sf_internal_get_sim_state_c13_fig711(SimStruct* S)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_raw2high");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = (mxArray*) get_sim_state_c13_fig711((SFc13_fig711InstanceStruct*)
    chartInfo->chartInstance);         /* raw sim ctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c13_fig711();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_raw2high'.\n");
  }

  return plhs[0];
}

extern void sf_internal_set_sim_state_c13_fig711(SimStruct* S, const mxArray *st)
{
  ChartInfoStruct *chartInfo = (ChartInfoStruct*) ssGetUserData(S);
  mxArray *plhs[1] = { NULL };

  mxArray *prhs[4];
  int mxError = 0;
  prhs[0] = mxCreateString("chart_simctx_high2raw");
  prhs[1] = mxCreateDoubleScalar(ssGetSFuncBlockHandle(S));
  prhs[2] = mxDuplicateArray(st);      /* high level simctx */
  prhs[3] = (mxArray*) sf_get_sim_state_info_c13_fig711();/* state var info */
  mxError = sf_mex_call_matlab(1, plhs, 4, prhs, "sfprivate");
  mxDestroyArray(prhs[0]);
  mxDestroyArray(prhs[1]);
  mxDestroyArray(prhs[2]);
  mxDestroyArray(prhs[3]);
  if (mxError || plhs[0] == NULL) {
    sf_mex_error_message("Stateflow Internal Error: \nError calling 'chart_simctx_high2raw'.\n");
  }

  set_sim_state_c13_fig711((SFc13_fig711InstanceStruct*)chartInfo->chartInstance,
    mxDuplicateArray(plhs[0]));
  mxDestroyArray(plhs[0]);
}

static const mxArray* sf_opaque_get_sim_state_c13_fig711(SimStruct* S)
{
  return sf_internal_get_sim_state_c13_fig711(S);
}

static void sf_opaque_set_sim_state_c13_fig711(SimStruct* S, const mxArray *st)
{
  sf_internal_set_sim_state_c13_fig711(S, st);
}

static void sf_opaque_terminate_c13_fig711(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc13_fig711InstanceStruct*) chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
    }

    finalize_c13_fig711((SFc13_fig711InstanceStruct*) chartInstanceVar);
    free((void *)chartInstanceVar);
    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc13_fig711((SFc13_fig711InstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c13_fig711(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c13_fig711((SFc13_fig711InstanceStruct*)(((ChartInfoStruct
      *)ssGetUserData(S))->chartInstance));
  }
}

static void mdlSetWorkWidths_c13_fig711(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable(S,"fig711","fig711",13);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,sf_rtw_info_uint_prop(S,"fig711","fig711",13,"RTWCG"));
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop(S,"fig711","fig711",13,
      "gatewayCannotBeInlinedMultipleTimes"));
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 3, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,"fig711","fig711",13,4);
      sf_mark_chart_reusable_outputs(S,"fig711","fig711",13,1);
    }

    sf_set_rtw_dwork_info(S,"fig711","fig711",13);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
  } else {
  }

  ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  ssSetChecksum0(S,(645573683U));
  ssSetChecksum1(S,(1469513231U));
  ssSetChecksum2(S,(3417222599U));
  ssSetChecksum3(S,(1380884872U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
}

static void mdlRTW_c13_fig711(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    sf_write_symbol_mapping(S, "fig711", "fig711",13);
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlStart_c13_fig711(SimStruct *S)
{
  SFc13_fig711InstanceStruct *chartInstance;
  chartInstance = (SFc13_fig711InstanceStruct *)malloc(sizeof
    (SFc13_fig711InstanceStruct));
  memset(chartInstance, 0, sizeof(SFc13_fig711InstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway = sf_opaque_gateway_c13_fig711;
  chartInstance->chartInfo.initializeChart = sf_opaque_initialize_c13_fig711;
  chartInstance->chartInfo.terminateChart = sf_opaque_terminate_c13_fig711;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c13_fig711;
  chartInstance->chartInfo.disableChart = sf_opaque_disable_c13_fig711;
  chartInstance->chartInfo.getSimState = sf_opaque_get_sim_state_c13_fig711;
  chartInstance->chartInfo.setSimState = sf_opaque_set_sim_state_c13_fig711;
  chartInstance->chartInfo.getSimStateInfo = sf_get_sim_state_info_c13_fig711;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c13_fig711;
  chartInstance->chartInfo.mdlStart = mdlStart_c13_fig711;
  chartInstance->chartInfo.mdlSetWorkWidths = mdlSetWorkWidths_c13_fig711;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->S = S;
  ssSetUserData(S,(void *)(&(chartInstance->chartInfo)));/* register the chart instance with simstruct */
  init_dsm_address_info(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  sf_opaque_init_subchart_simstructs(chartInstance->chartInfo.chartInstance);
}

void c13_fig711_method_dispatcher(SimStruct *S, int_T method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c13_fig711(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c13_fig711(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c13_fig711(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c13_fig711_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
